$(document).ready(function() {
    $(document).on("click", ".printBtn", function (){
       window.print();
    });
});