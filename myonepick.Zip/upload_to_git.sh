#!/bin/bash
git add --all

git commit -m "merge"

git pull origin master

git push origin master



