#!/bin/bash
ssh -X -i ksnpick.cer -t ubuntu@3.35.16.229 "cd /home/ubuntu/picktalk/ ; bash"