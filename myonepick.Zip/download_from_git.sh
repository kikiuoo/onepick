#!/bin/bash
git fetch 

git add --all

git commit -m "merge"

git pull origin master

